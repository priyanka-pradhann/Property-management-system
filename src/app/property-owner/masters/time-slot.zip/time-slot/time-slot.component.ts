import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ApiService } from 'src/app/services/api/api.service';

@Component({
  selector: 'app-time-slot',
  templateUrl: './time-slot.component.html',
  styleUrls: ['./time-slot.component.css']
})
export class TimeSlotComponent {
  closeResult = '';

  successval:any='successeeeee';
  click:any=false;

  timeSlotArray: any;
  apiResponse: any;


  message:any='';

  constructor(private modalService: NgbModal, private apiService: ApiService) {

  }

  ngOnInit(){
    this.getTimeSlotData();
  }

  async getTimeSlotData(){

    this.apiResponse = await this.apiService.getTimeSlotData();

    if(this.apiResponse){
      if(this.apiResponse.time_slot != null && this.apiResponse.time_slot != 'undefined'){
        this.timeSlotArray = this.apiResponse.time_slot;
        console.log('Timeslot ' + JSON.stringify(this.timeSlotArray));
      }
    }
  }

  checkActive(){
    this.message="Please fill all the details.";
  }
  checkactive(){
    console.log("Function works");
    this.click=true;
  }


  openModal(content: any){

    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', size: 'sm' }).result.then((result: any) => {
      this.closeResult = `Closed with: ${result}`;

    }, (reason: any) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  getDismissReason(reason: any) {
    throw new Error('Method not implemented.');
  }
}
